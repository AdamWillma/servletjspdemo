package com.example.formservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.formservlet.domain.Zwierze;

@WebServlet(urlPatterns = "/addZwierze")
public class FormServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String CheckWoman(String arg){
		if(arg.startsWith("K")){
		return "checked='checked'";
		}
		else return "";
	}
	
	public String CheckMan(String arg){
		if(arg.startsWith("M")){
		return "checked='checked'";
		}
		else return "";
	}
	
	public String CheckKurczak(String arg[]){
		int j=0;
		for(int i=0; i<arg.length; i++){
			if(arg[i]!=null){
			if(arg[i].equals("kurczak")){
				j=1;
			}
			}
		}
		if(j==1) return "checked='checked'";
		else return "";
	}
	
	public String CheckWolowina(String arg[]){
		int j=0;
		for(int i=0; i<arg.length; i++){
			if(arg[i]!=null){
				if(arg[i].equals("wolowina")){
					j=1;
				}
				}
		}
		if(j==1) return "checked='checked'";
		else return "";
	}
	
	public String CheckCielecina(String arg[]){
		int j=0;
		for(int i=0; i<arg.length; i++){
			if(arg[i]!=null){
				if(arg[i].equals("cielecina")){
					j=1;
				}
				}
		}
		if(j==1) return "checked='checked'";
		else return "";
	}
	
	public String CheckWarzywa(String arg[]){
		int j=0;
		for(int i=0; i<arg.length; i++){
			if(arg[i]!=null){
				if(arg[i].equals("warzywa")){
					j=1;
				}
				}
		}
		if(j==1) return "checked='checked'";
		else return "";
	}
	
	public String CheckPies(String arg){
		if(arg.startsWith("Pies")){
		return "selected='selected'";
		}
		else return "";
	}
	
	public String CheckKot(String arg){
		if(arg.startsWith("Kot")){
		return "selected='selected'";
		}
		else return "";
	}
	
	public String CheckKon(String arg){
		if(arg.startsWith("Kon")){
		return "selected='selected'";
		}
		else return "";
	}
	
	public String CheckKrolik(String arg){
		if(arg.startsWith("Krolik")){
		return "selected='selected'";
		}
		else return "";
	}
	
	public String CheckKrowa(String arg){
		if(arg.startsWith("Krowa")){
		return "selected='selected'";
		}
		else return "";
	}
	
	public String CheckPlywanie(String arg[]){
		int j=0;
		for(int i=0; i<arg.length; i++){
			if(arg[i]!=null){
				if(arg[i].equals("Plywanie")){
					j=1;
				}
				}
		}
		if(j==1) return "selected='selected'";
		else return "";
	}
	
	public String CheckSpanie(String arg[]){
		int j=0;
		for(int i=0; i<arg.length; i++){
			if(arg[i]!=null){
				if(arg[i].equals("Spanie")){
					j=1;
				}
				}
		}
		if(j==1) return "selected='selected'";
		else return "";
	}
	
	public String CheckBieganie(String arg[]){
		int j=0;
		for(int i=0; i<arg.length; i++){
			if(arg[i]!=null){
				if(arg[i].equals("Bieganie")){
					j=1;
				}
				}
		}
		if(j==1) return "selected='selected'";
		else return "";
	}
	
	public String CheckZabawa(String arg[]){
		int j=0;
		for(int i=0; i<arg.length; i++){
			if(arg[i]!=null){
				if(arg[i].equals("Zabawa")){
					j=1;
				}
				}
		}
		if(j==1) return "selected='selected'";
		else return "";
	}
	
	public String CheckGryzienie(String arg[]){
		int j=0;
		for(int i=0; i<arg.length; i++){
			if(arg[i]!=null){
				if(arg[i].equals("Gryzienie")){
					j=1;
				}
				}
		}
		if(j==1) return "selected='selected'";
		else return "";
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession httpSession = request.getSession();
		
		if(httpSession.getAttribute("zwierze")==null){
			httpSession.setAttribute("zwierze", new Zwierze());
		}
		
		Zwierze zwierze = (Zwierze) httpSession.getAttribute("zwierze");
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		out.print("<html><body><h2>Formularz dodawania zwierzecia:</h2>" +
				"<form action='zwierzeData'>" +
				"Imie: <input type='text' name='imie' value='"+zwierze.getImie()+"' /> <br />" +
				"Wiek: <input type='text' name='rok' value='"+zwierze.getWiek()+"' /> <br />" +
				"Plec: <input type='radio' name='plec' value='K' "+CheckWoman(zwierze.getPlec())+"/>Samica <input type='radio' name='plec' value='M' "+CheckMan(zwierze.getPlec())+"/>Samiec <br />" +
				"Ulubione potrawy: <input type='checkbox' name='potrawy' value='kurczak' "+CheckKurczak(zwierze.getPotrawy())+">Kurczak <input type='checkbox' name='potrawy' value='wolowina' "+CheckWolowina(zwierze.getPotrawy())+">Wolowina <input type='checkbox' name='potrawy' value='cielecina' "+CheckCielecina(zwierze.getPotrawy())+">Cielecina <input type='checkbox' name='potrawy' value='warzywa' "+CheckWarzywa(zwierze.getPotrawy())+">Warzywa <br />" +
				"Opis: <br /><textarea name='opis' cols='50' rows='10'>"+zwierze.getOpis()+"</textarea> <br />" +
				"Rodzaj: <select name='rodzaj'><option "+CheckPies(zwierze.getRodzaj())+">Pies</option><option "+CheckKot(zwierze.getRodzaj())+">Kot</option><option "+CheckKrolik(zwierze.getRodzaj())+">Krolik</option><option "+CheckKon(zwierze.getRodzaj())+">Kon</option><option  "+CheckKrowa(zwierze.getRodzaj())+">Krowa</option></select><br />" +
				"Ulubione zajecia: <br /> <select name='ulubione' multiple='multiple' size='5'><option "+CheckPlywanie(zwierze.getUlubione())+">Plywanie</option><option "+CheckSpanie(zwierze.getUlubione())+">Spanie</option><option "+CheckBieganie(zwierze.getUlubione())+">Bieganie</option><option "+CheckZabawa(zwierze.getUlubione())+">Zabawa</option><option "+CheckGryzienie(zwierze.getUlubione())+">Gryzienie</option></select><br />" +
				"<input type='submit' value=' OK ' />" +
				"</form>" +
				"</body></html>");
		out.close();
		
	}

}
