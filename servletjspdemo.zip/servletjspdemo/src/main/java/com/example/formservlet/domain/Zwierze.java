package com.example.formservlet.domain;

public class Zwierze {
	
	private String id = "";
	
	private String imie = "unknown";
	private String wiek = "0";
	
	private String[] potrawy = new String[4];
	private String opis = "Tutaj wpisz opis";
	private String plec = "M";
	private String rodzaj = "Brak";
	private String[] ulubione = new String[5];
	
	public Zwierze(){
		super();
	}
	
	public Zwierze(String id, String imie, String wiek, String plec, String[] potrawy, String opis, String rodzaj, String[] ulubione ){
		super();
		this.id = id;
		this.imie = imie;
		this.wiek = wiek;
		this.plec = plec;
		this.potrawy = potrawy;
		this.opis = opis;
		this.rodzaj = rodzaj;
		this.ulubione = ulubione;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getImie() {
		return imie;
	}

	public void setImie(String imie) {
		this.imie = imie;
	}

	public String getWiek() {
		return wiek;
	}

	public void setWiek(String wiek) {
		this.wiek = wiek;
	}

	public String[] getPotrawy() {
		return potrawy;
	}

	public void setPotrawy(String[] potrawy) {
		this.potrawy = potrawy;
	}

	public String getOpis() {
		return opis;
	}

	public void setOpis(String opis) {
		this.opis = opis;
	}

	public String getPlec() {
		return plec;
	}

	public void setPlec(String plec) {
		this.plec = plec;
	}

	public String getRodzaj() {
		return rodzaj;
	}

	public void setRodzaj(String rodzaj) {
		this.rodzaj = rodzaj;
	}

	public String[] getUlubione() {
		return ulubione;
	}

	public void setUlubione(String[] ulubione) {
		this.ulubione = ulubione;
	}
	
	

}
