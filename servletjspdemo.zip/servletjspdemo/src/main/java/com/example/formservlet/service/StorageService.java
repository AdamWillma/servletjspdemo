package com.example.formservlet.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.example.formservlet.domain.Zwierze;

public class StorageService {
	
public String RandomId(){
	Random random = new Random();
	int id = random.nextInt();
	while(id<=0) id = random.nextInt();
	String end = Integer.toString(id);
	return end;
}
	
public List<Zwierze> db = new ArrayList<Zwierze>();
	
	public void add(Zwierze zwierze){
		Zwierze newZwierze = new Zwierze(zwierze.getId(), zwierze.getImie(), zwierze.getWiek(), zwierze.getPlec(), zwierze.getPotrawy(), zwierze.getOpis(), zwierze.getRodzaj(), zwierze.getUlubione());
		db.add(newZwierze);
	}
	
	public void delete(String id){
		int index = -1;
		for(Zwierze zwierzak : db){
			if(id.equals(zwierzak.getId())){
				index = db.indexOf(zwierzak);
				break;
			}
		}
		db.remove(index);
	}
	
	public void update(String id, Zwierze zwierze){
		int index = -1;
		for(Zwierze zwierzak : db){
			if(id.equals(zwierzak.getId())){
				index = db.indexOf(zwierzak);
				break;
			}
		}
		Zwierze newZwierze = new Zwierze(zwierze.getId(), zwierze.getImie(), zwierze.getWiek(), zwierze.getPlec(), zwierze.getPotrawy(), zwierze.getOpis(), zwierze.getRodzaj(), zwierze.getUlubione());
		db.set(index, newZwierze);
	}
	
	public List<Zwierze> getAllZwierze(){
		return db;
	}

}
