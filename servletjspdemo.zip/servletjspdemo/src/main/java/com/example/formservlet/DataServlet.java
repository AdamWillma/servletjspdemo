package com.example.formservlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.formservlet.domain.Zwierze;
import com.example.formservlet.service.StorageService;

@WebServlet(urlPatterns = "/zwierzeData")

public class DataServlet extends HttpServlet {
	StorageService ss = new StorageService();
	 
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession httpSession = request.getSession();

		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		
		String[] selectedPotrawy = new String[4];
		int i=0;
		for (String potrawa : request.getParameterValues("potrawy")) {
			selectedPotrawy[i]=potrawa;
			i++;
		}
		
		String selectedPotrawy1 = "";
		
		for(int j=0; j<i; j++){
			selectedPotrawy1+=selectedPotrawy[j];
			if(j<i-1) selectedPotrawy1+=", ";
		}

		int k=0;
		
		String[] selectedUlubione = new String[5];
		for (String ulubione : request.getParameterValues("ulubione")) {
			selectedUlubione[k]=ulubione;
			k++;
		}
		
		String selectedUlubione1 = "";
		
		for(int j=0; j<k; j++){
			selectedUlubione1+=selectedUlubione[j];
			if(j<k-1) selectedUlubione1+=", ";
		}
		
		Random random = new Random();
		
		String id = Integer.toString(random.nextInt());
		
		String imie = request.getParameter("imie");
		String wiek = request.getParameter("rok");
		String plec = request.getParameter("plec");
		String opis = request.getParameter("opis");
		String rodzaj = request.getParameter("rodzaj");
		
		out.println("<html><body><h2>Twoje zwierze:</h2>" +
				"<p>Id: " + id + "<br />" +
				"<p>Imie: " + imie + "<br />" +
				"<p>Wiek: " + wiek + "<br />" +
				"<p>Plec: " + plec + "<br />" +
				"<p>Ulubione potrawy: " + selectedPotrawy1 + "<br />" +
				"<p>Opis: " + opis + "<br />" +
				"<p>Rodzaj: " + rodzaj + "<br />" +
				"<p>Ulubione zajecia: " + selectedUlubione1 + "<br />");
		
		Zwierze z = new Zwierze();
		z.setId(id);
		z.setImie(imie);
		z.setWiek(wiek);
		z.setPotrawy(selectedPotrawy);
		z.setPlec(plec);
		z.setUlubione(selectedUlubione);
		z.setOpis(opis);
		z.setRodzaj(rodzaj);

		ss.add(z);
		
		httpSession.setAttribute("zwierze", z);

		out.println("<br /><h2>Lista zwierzat:</h2><br /><br />");

		for(Zwierze zwierze : ss.getAllZwierze()){
			String[] potrawy = zwierze.getPotrawy();
			String[] ulubione = zwierze.getUlubione();
			String potrawy1 = "";
			String ulubione1 = "";
			for(int l=0; l<i; l++){
				potrawy1+=potrawy[l];
				if(l<i-1) potrawy1+=", ";
			}
			for(int l=0; l<k; l++){
				ulubione1+=ulubione[l];
				if(l<k-1) ulubione1+=", ";
			}
			out.println(zwierze.getId()+". "+zwierze.getImie()+", "+zwierze.getPlec()+", "+zwierze.getWiek()+", "+potrawy1+", "+ulubione1+", "+zwierze.getRodzaj()+", "+zwierze.getOpis()+"<br />");
		}
		
		out.println("</body></html>");
		
		k=0;
		i=0;
		
		out.close();
			
		
		
		
	}

}
