package com.example.formservlet;

public enum Plec {
	M,K;
}
