package com.example.formservlet.service;

import java.util.ArrayList;
import java.util.List;

import com.example.formservlet.domain.Zwierze;

public class StorageService {
	
public List<Zwierze> db = new ArrayList<Zwierze>();
	
	public void add(Zwierze zwierze){
		Zwierze newZwierze = new Zwierze(zwierze.getImie(), zwierze.getWiek(), zwierze.getPlec(), zwierze.getPotrawy(), zwierze.getOpis(), zwierze.getRodzaj(), zwierze.getUlubione());
		db.add(newZwierze);
	}
	
	public List<Zwierze> getAllZwierze(){
		return db;
	}

}
