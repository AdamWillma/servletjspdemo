package com.example.formservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.example.formservlet.domain.Zwierze;

@WebServlet(urlPatterns = "/addZwierze")
public class FormServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String CheckWoman(String arg){
		if(arg.startsWith("K")){
		return "checked='checked'";
		}
		else return "";
	}
	
	public String CheckMan(String arg){
		if(arg.startsWith("M")){
		return "checked='checked'";
		}
		else return "";
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession httpSession = request.getSession();
		
		if(httpSession.getAttribute("zwierze")==null){
			httpSession.setAttribute("zwierze", new Zwierze());
		}
		
		Zwierze zwierze = (Zwierze) httpSession.getAttribute("zwierze");
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		out.print("<html><body><h2>Formularz dodawania zwierzecia:</h2>" +
				"<form action='zwierzeData'>" +
				"Imie: <input type='text' name='imie' value='"+zwierze.getImie()+"' /> <br />" +
				"Wiek: <input type='text' name='rok' value='"+zwierze.getWiek()+"' /> <br />" +
				"Plec: <input type='radio' name='plec' value='K' "+CheckWoman(zwierze.getPlec())+"/>Samica <input type='radio' name='plec' value='M' "+CheckMan(zwierze.getPlec())+"/>Samiec <br />" +
				"Ulubione potrawy: <input type='checkbox' name='potrawy' value='kurczak' "+">Kurczak <input type='checkbox' name='potrawy' value='wolowina' "+">Wolowina <input type='checkbox' name='potrawy' value='cielecina' "+">Cielecina <input type='checkbox' name='potrawy' value='warzywa' "+">Warzywa <br />" +
				"Opis: <br /><textarea name='opis' cols='50' rows='10'>"+zwierze.getOpis()+"</textarea> <br />" +
				"Rodzaj: <select name='rodzaj'><option "+">Pies</option><option "+">Kot</option><option "+">Krolik</option><option "+">Kon</option><option  "+">Krowa</option></select><br />" +
				"Ulubione zajecia: <br /> <select name='ulubione' multiple='multiple' size='5'><option "+">Plywanie</option><option "+">Spanie</option><option "+">Bieganie</option><option "+">Zabawa</option><option "+">Gryzienie</option></select><br />" +
				"<input type='submit' value=' OK ' />" +
				"</form>" +
				"</body></html>");
		out.close();
		
	}

}
